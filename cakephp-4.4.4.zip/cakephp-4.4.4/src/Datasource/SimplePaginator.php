<?php
declare(strict_types=1);

class_alias(
    'Cake\Datasource\Paging\SimplePaginator',
    'Cake\Datasource\SimplePaginator'
);
deprecationWarning(
    'Use Cake\Datasource\Paging\SimplePaginator instead of Cake\Datasource\SimplePaginator.'
);
