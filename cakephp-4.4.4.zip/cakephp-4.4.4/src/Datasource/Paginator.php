<?php
declare(strict_types=1);

class_alias(
    'Cake\Datasource\Paging\NumericPaginator',
    'Cake\Datasource\Paginator'
);
deprecationWarning(
    'Use Cake\Datasource\Paging\NumericPaginator instead of Cake\Datasource\Paginator.'
);
