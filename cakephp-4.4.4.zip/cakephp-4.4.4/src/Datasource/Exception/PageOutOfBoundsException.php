<?php
declare(strict_types=1);

class_alias(
    'Cake\Datasource\Paging\Exception\PageOutOfBoundsException',
    'Cake\Datasource\Exception\PageOutOfBoundsException'
);
