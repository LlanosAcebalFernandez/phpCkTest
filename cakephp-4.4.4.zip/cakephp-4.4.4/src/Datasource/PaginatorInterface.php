<?php
declare(strict_types=1);

class_alias(
    'Cake\Datasource\Paging\PaginatorInterface',
    'Cake\Datasource\PaginatorInterface'
);
deprecationWarning(
    'Use Cake\Datasource\Paging\PaginatorInterface instead of Cake\Datasource\PaginatorInterface.'
);
